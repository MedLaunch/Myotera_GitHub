// This file is needed by CMAKE. It can't generate empty libraries.
